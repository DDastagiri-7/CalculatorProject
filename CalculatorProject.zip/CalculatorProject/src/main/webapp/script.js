let display =
    document.getElementById("display");


// ========================================
// ADD VALUE
// ========================================

function appendValue(value) {

    if (display.value === "Error") {

        display.value = "0";
    }


    // Opening bracket
    if (value === "(") {

        if (display.value === "0") {

            display.value = "(";

        } else {

            let last =
                display.value.charAt(
                    display.value.length - 1
                );

            // Automatically add multiplication
            if (
                !isOperator(last) &&
                last !== "("
            ) {

                display.value += "*";
            }

            display.value += "(";
        }

        return;
    }


    // Closing bracket
    if (value === ")") {

        let open =
            (display.value.match(/\(/g) || []).length;

        let close =
            (display.value.match(/\)/g) || []).length;


        // Don't allow invalid closing bracket
        if (open <= close) {

            return;
        }


        let last =
            display.value.charAt(
                display.value.length - 1
            );


        // Don't close immediately after operator
        if (
            isOperator(last) ||
            last === "("
        ) {

            return;
        }


        display.value += ")";

        return;
    }


    // Operators
    if (isOperator(value)) {

        if (
            display.value === "0" ||
            display.value === "("
        ) {

            return;
        }


        let last =
            display.value.charAt(
                display.value.length - 1
            );


        // Replace previous operator
        if (isOperator(last)) {

            display.value =
                display.value.slice(0, -1) + value;

            return;
        }


        display.value += value;

        return;
    }


    // Decimal
    if (value === ".") {

        let parts =
            display.value.split(
                /[\+\-\*\/\(\)]/
            );


        let currentNumber =
            parts[parts.length - 1];


        if (currentNumber.includes(".")) {

            return;
        }


        display.value += value;

        return;
    }


    // Number
    if (display.value === "0") {

        display.value = value;

    } else {

        display.value += value;
    }
}


// ========================================
// OPERATOR CHECK
// ========================================

function isOperator(value) {

    return (
        value === "+" ||
        value === "-" ||
        value === "*" ||
        value === "/"
    );
}


// ========================================
// CLEAR
// ========================================

function clearDisplay() {

    display.value = "0";
}


// ========================================
// DELETE
// ========================================

function deleteLast() {

    if (
        display.value === "Error" ||
        display.value.length <= 1
    ) {

        display.value = "0";

    } else {

        display.value =
            display.value.slice(0, -1);
    }
}


// ========================================
// PERCENTAGE
// ========================================

function percentage() {

    let value =
        parseFloat(display.value);


    if (isNaN(value)) {

        return;
    }


    display.value =
        value / 100;
}


// ========================================
// SQUARE ROOT
// ========================================

function squareRoot() {

    let value =
        parseFloat(display.value);


    if (
        isNaN(value) ||
        value < 0
    ) {

        display.value = "Error";

        return;
    }


    let result =
        Math.sqrt(value);


    display.value =
        formatResult(result);


    saveHistory(
        "√" + value,
        result
    );
}


// ========================================
// SQUARE
// ========================================

function square() {

    let value =
        parseFloat(display.value);


    if (isNaN(value)) {

        return;
    }


    let result =
        value * value;


    display.value =
        formatResult(result);


    saveHistory(
        value + "²",
        result
    );
}


// ========================================
// PI
// ========================================

function appendPi() {

    if (display.value === "0") {

        display.value =
            Math.PI.toString();

    } else {

        display.value += Math.PI;
    }
}


// ========================================
// SIN
// ========================================

function sinValue() {

    let value =
        parseFloat(display.value);


    if (isNaN(value)) {

        return;
    }


    let result =
        Math.sin(
            value * Math.PI / 180
        );


    display.value =
        formatResult(result);


    saveHistory(
        "sin(" + value + "°)",
        result
    );
}


// ========================================
// COS
// ========================================

function cosValue() {

    let value =
        parseFloat(display.value);


    if (isNaN(value)) {

        return;
    }


    let result =
        Math.cos(
            value * Math.PI / 180
        );


    display.value =
        formatResult(result);


    saveHistory(
        "cos(" + value + "°)",
        result
    );
}


// ========================================
// TAN
// ========================================

function tanValue() {

    let value =
        parseFloat(display.value);


    if (isNaN(value)) {

        return;
    }


    let result =
        Math.tan(
            value * Math.PI / 180
        );


    display.value =
        formatResult(result);


    saveHistory(
        "tan(" + value + "°)",
        result
    );
}


// ========================================
// FORMAT RESULT
// ========================================

function formatResult(result) {

    return Number(
        result.toFixed(10)
    );
}


// ========================================
// CALCULATE
// ========================================

function calculate() {

    try {

        let expression =
            display.value;


        if (
            expression === "" ||
            expression === "0"
        ) {

            return;
        }


        let last =
            expression.charAt(
                expression.length - 1
            );


        // Don't end with operator
        if (isOperator(last)) {

            return;
        }


        // Check brackets
        let open =
            (expression.match(/\(/g) || []).length;

        let close =
            (expression.match(/\)/g) || []).length;


        if (open !== close) {

            display.value = "Error";

            return;
        }


        let result =
            eval(expression);


        if (!isFinite(result)) {

            display.value = "Error";

            return;
        }


        display.value =
            formatResult(result);


        saveHistory(
            expression,
            result
        );

    }

    catch (error) {

        display.value = "Error";
    }
}


// ========================================
// SAVE HISTORY
// ========================================

function saveHistory(
    expression,
    result
) {

    let history =
        JSON.parse(
            localStorage.getItem(
                "calculatorHistory"
            )
        ) || [];


    history.unshift({

        expression: expression,

        result: formatResult(result)

    });


    if (history.length > 20) {

        history.pop();
    }


    localStorage.setItem(
        "calculatorHistory",
        JSON.stringify(history)
    );


    displayHistory();
}


// ========================================
// DISPLAY HISTORY
// ========================================

function displayHistory() {

    let history =
        JSON.parse(
            localStorage.getItem(
                "calculatorHistory"
            )
        ) || [];


    let historyList =
        document.getElementById(
            "historyList"
        );


    historyList.innerHTML = "";


    history.forEach(function(item) {

        let div =
            document.createElement("div");


        div.className =
            "history-item";


        div.innerHTML =
            item.expression +
            " = " +
            item.result;


        historyList.appendChild(div);

    });
}


// ========================================
// CLEAR HISTORY
// ========================================

function clearHistory() {

    localStorage.removeItem(
        "calculatorHistory"
    );


    displayHistory();
}


// ========================================
// KEYBOARD
// ========================================

document.addEventListener(
    "keydown",
    function(event) {

        let key = event.key;


        if (
            key >= "0" &&
            key <= "9"
        ) {

            appendValue(key);
        }


        else if (
            key === "+" ||
            key === "-" ||
            key === "*" ||
            key === "/"
        ) {

            appendValue(key);
        }


        else if (
            key === "(" ||
            key === ")"
        ) {

            appendValue(key);
        }


        else if (key === ".") {

            appendValue(".");
        }


        else if (key === "%") {

            percentage();
        }


        else if (key === "Enter") {

            calculate();
        }


        else if (key === "Backspace") {

            deleteLast();
        }


        else if (key === "Escape") {

            clearDisplay();
        }

    }
);


// ========================================
// DARK / LIGHT MODE
// ========================================

function toggleTheme() {

    document.body.classList.toggle(
        "dark-mode"
    );


    let themeButton =
        document.getElementById(
            "themeButton"
        );


    if (
        document.body.classList.contains(
            "dark-mode"
        )
    ) {

        themeButton.innerHTML =
            "☀️ Light Mode";


        localStorage.setItem(
            "theme",
            "dark"
        );

    } else {

        themeButton.innerHTML =
            "🌙 Dark Mode";


        localStorage.setItem(
            "theme",
            "light"
        );
    }
}


// ========================================
// LOAD THEME
// ========================================

function loadTheme() {

    let savedTheme =
        localStorage.getItem(
            "theme"
        );


    let themeButton =
        document.getElementById(
            "themeButton"
        );


    if (savedTheme === "dark") {

        document.body.classList.add(
            "dark-mode"
        );


        themeButton.innerHTML =
            "☀️ Light Mode";

    } else {

        themeButton.innerHTML =
            "🌙 Dark Mode";
    }
}


// ========================================
// PAGE LOAD
// ========================================

displayHistory();

loadTheme();